
#ifndef __START_H
#define __START_H
#ifdef __cplusplus
extern "C"
{
#endif
void startup(void);
#ifdef __cplusplus
}
#endif

#endif 