#ifndef __MOTOR_CONTROL_H
#define __MOTOR_CONTROL_H
#ifdef __cplusplus
/*
 *
 * 适用于驱动使用类似L298N驱动板的直流编码电机
 *
 */
extern "C"
{
#endif

#include "main.h"

class Pid
{
    float loutput;
    float intg;
    float lerr;
    int max_output;
    int max_intg;
public:
    float Kp,Ki,Kd;
    float err;
    float calculate(float tgt_val,float cur_val);
    Pid(float kp, float ki, float kd,int max=2147483646,int mi=500)
    {
        Kp = kp;
        Ki = ki;
        Kd = kd;
        lerr =0;
        intg=0;
        max_output=max;
        max_intg=mi;
    }
    void reset();
};

class Motor
{
    /*
     * 用ena in1，in2 pwm控制的电机
     * 电机参数：减速比5.2
     * 编码器 16ppm
     *
     */

    //电机引脚
    TIM_HandleTypeDef *mhtim; uint32_t mChannel;
    GPIO_TypeDef *in1_GPIO_Port; uint16_t in1_Pin;
    GPIO_TypeDef *in2_GPIO_Port; uint16_t in2_Pin;
    GPIO_TypeDef *Sa_GPIO_Port;uint16_t Sa_Pin;
    Pid pid1;

public:
    int ct;
    int speed ;
    float ranger ;
    bool mv_rounds(float r, bool reverse=0);
    bool set_speed();
    int measure_speed();
    void init();
    void GPIO_EXTI_Callback(uint16_t GPIO_Pin);

    Motor(TIM_HandleTypeDef *htim, uint32_t Channel,
          GPIO_TypeDef *in1_GPIOx, uint16_t in1p,
          GPIO_TypeDef *in2_GPIOx, uint16_t in2p,
          GPIO_TypeDef *Sa_GPIOx,uint16_t Sap) : pid1(0.5,0.01,0.1,900,600)
    {
        in1_GPIO_Port= in1_GPIOx;
        in1_Pin = in1p;
        in2_GPIO_Port = in2_GPIOx;
        in2_Pin = in2p;
        Sa_GPIO_Port = Sa_GPIOx;
        Sa_Pin = Sap;
        speed = 0;
        ranger = 0;
        ct = 0;
        mhtim= htim;
        mChannel=Channel;


    }


};

#ifdef __cplusplus
}
#endif

#endif
