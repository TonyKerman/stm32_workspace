//
// Created by Lenovo on 2022/11/12.
//

#include "motor_control.h"
using namespace std;

void Pid::reset()
{
    lerr =0;
    intg=0;
}

float Pid::calculate(float tgt_val,float cur_val) {

    float output;
    err = tgt_val - cur_val;
    intg += err;
    //PID:
    output = int(Kp*err + Ki * intg + (err - lerr) * Kd);
    lerr = err;
    if(output>float(max_output))
    {
        output=float(max_output);
    }
    else if(output<float(-1*max_output))
    {
        output=-1*max_output;
    }
    return output;
}


void Motor::init()
{
    HAL_TIM_PWM_Start(mhtim,mChannel);
    __HAL_TIM_SET_COMPARE(mhtim, mChannel,0);

}

int Motor::measure_speed() {

    ct=0;
    return 0;
}

void Motor::GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == Sa_Pin)
    {
     ct++;
     ranger+=(1.0/32)/5.2;
    }
}

bool Motor::mv_rounds(float r , bool reverse )
{
    int duty = int(pid1.calculate(r,ranger));
    if(reverse)
    {
        if(duty>=0)
        {
            HAL_GPIO_WritePin(in1_GPIO_Port,in1_Pin,GPIO_PIN_SET) ;
            HAL_GPIO_WritePin(in2_GPIO_Port,in2_Pin,GPIO_PIN_RESET);
        } else
        {
            HAL_GPIO_WritePin(in1_GPIO_Port,in1_Pin,GPIO_PIN_SET) ;
            HAL_GPIO_WritePin(in2_GPIO_Port,in2_Pin,GPIO_PIN_RESET);
        }

    }
    else
    {
        if(duty>=0)
        {
            HAL_GPIO_WritePin(in1_GPIO_Port, in1_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(in2_GPIO_Port, in2_Pin, GPIO_PIN_SET);
        } else
        {
            HAL_GPIO_WritePin(in1_GPIO_Port,in1_Pin,GPIO_PIN_SET) ;
            HAL_GPIO_WritePin(in2_GPIO_Port,in2_Pin,GPIO_PIN_RESET);
        }
    }

    if(pid1.err<=0.1)
    {
        pid1.reset();
        HAL_GPIO_WritePin(in1_GPIO_Port,in1_Pin,GPIO_PIN_RESET);
        HAL_GPIO_WritePin(in2_GPIO_Port,in2_Pin,GPIO_PIN_RESET);
        __HAL_TIM_SET_COMPARE(mhtim, mChannel,0);
        return false;

    }
    __HAL_TIM_SET_COMPARE(mhtim, mChannel,duty);
    return true;
}

bool Motor::set_speed() {
    return false;
}

