//
// Created by Lenovo on 2022/9/24.
//
#include "start.h"
#include "main.h"
#include "tim.h"
#include "motor_control.h"
#include <string>
using namespace std;
#define LED_GREEN_ON() HAL_GPIO_WritePin(LDG_GPIO_Port,LDG_Pin,GPIO_PIN_RESET)
#define LED_GREEN_OFF() HAL_GPIO_WritePin(LDG_GPIO_Port,LDG_Pin,GPIO_PIN_SET)
Motor ml(&htim2,TIM_CHANNEL_1,
         IN1_GPIO_Port,IN1_Pin,
         IN2_GPIO_Port,IN2_Pin,
         HALL_A_GPIO_Port,HALL_A_Pin
);

string str;
void setup()
{
    HAL_GPIO_WritePin(LDR_GPIO_Port,LDR_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(VCC_GPIO_Port,VCC_Pin,GPIO_PIN_SET);
    LED_GREEN_ON();
    HAL_Delay(500);
    LED_GREEN_OFF();
    HAL_Delay(500);
    LED_GREEN_ON();
    HAL_Delay(500);
    LED_GREEN_OFF();
    HAL_TIM_Base_Start_IT(&htim1);
    HAL_TIM_Base_Start_IT(&htim2);
    //str = "Hello!";
    //HAL_UART_Transmit(&huart2,(uint8_t *)str.data(),str.size(),10);
    ml.init();
    while (ml.mv_rounds(100)){}
    HAL_GPIO_WritePin(LDR_GPIO_Port,LDR_Pin,GPIO_PIN_SET);
}


void loop()
{
    //wait for start

    //turn


    //turn

    // wait for ball

    //
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance==htim1.Instance)
    {
        /*
         * TIM1:Pried = 1ms
         * Contrel PWM
         */
        //HAL_GPIO_TogglePin(LDG_GPIO_Port,LDG_Pin);

        // car move functions:
    }
    if (htim->Instance==htim2.Instance)
    {
        /*
         * TIM2 :Pried = 10 ms
         * 测量电机转速
         */
       // ml.measure_speed();
        HAL_GPIO_TogglePin(LDG_GPIO_Port,LDG_Pin);
        //mr.measure_speed();
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    ml.GPIO_EXTI_Callback(GPIO_Pin);
    HAL_GPIO_TogglePin(LDG_GPIO_Port,LDG_Pin);
}
