//
// Created by Lenovo on 2022/9/24.
//
#include "start.h"
#include "main.h"
#include "gpio.h"
#include <string>
using namespace std;
#define LED_GREEN_ON() HAL_GPIO_WritePin(LDG_GPIO_Port,LDG_Pin,GPIO_PIN_RESET)
#define LED_GREEN_OFF() HAL_GPIO_WritePin(LDG_GPIO_Port,LDG_Pin,GPIO_PIN_SET)

void setup()
{
    LED_GREEN_ON();
    HAL_Delay(500);
    LED_GREEN_OFF();
    HAL_Delay(500);
    LED_GREEN_ON();
    HAL_Delay(500);
    LED_GREEN_OFF();
}


void loop()
{
    HAL_GPIO_TogglePin(LDG_GPIO_Port,LDG_Pin);
    HAL_Delay(1000);
}

