//
// Created by Lenovo on 2022/9/24.
//


#ifndef __START_H
#define __START_H
#ifdef __cplusplus
extern "C"
{
#endif
void setup(void);
void loop(void);
#ifdef __cplusplus
}
#endif

#endif 

