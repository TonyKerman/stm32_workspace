//
// Created by Lenovo on 2022/11/14.
//


enum mv_states{stop,forword,backword,tnleft,tnright};
void move(mv_states s,int arg=0)
{
    switch (s)
    {
        case stop:
            break;
    }
}


